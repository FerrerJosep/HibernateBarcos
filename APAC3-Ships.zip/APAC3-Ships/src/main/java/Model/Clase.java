/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Entity;

/**
 *
 * @author josep
 */


@Getter@Setter@NoArgsConstructor
@Data
@Entity
@Table(name="class")
public class Clase implements Serializable{
    
    static final long serialVersionUID=10L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)            
    String Classe;
    
    @Column
    String TipusBarco;
    
    @Column
    String Pais;
    
    @Column
    int NumArma;
    
    @OneToMany(mappedBy="Classe",
            cascade=CascadeType.PERSIST, 
            fetch= FetchType.LAZY)
    private Set<Barco> elsBarcos;
}
