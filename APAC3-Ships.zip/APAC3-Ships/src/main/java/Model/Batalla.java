/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Entity;

/**
 *
 * @author josep
 */
@Getter@Setter@NoArgsConstructor
@Data
@Entity
@Table(name="battles")
public class Batalla {
    
    @Column 
    @Id
    private String name;
    
    
    @Column
    private String Data;
    
    @ManyToMany(cascade=CascadeType.PERSIST,
            fetch=FetchType.LAZY)
    @JoinTable(name="Barco",
              joinColumns = {@JoinColumn(name="name",foreignKey = @ForeignKey(name = "" ))},
              inverseJoinColumns = {@JoinColumn(name="Nom",foreignKey = @ForeignKey(name = "" ))}        
        )
    private Set<Barco> losBarcos=new HashSet<>();;
  
    
    
}
