/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Entity;
/**
 *
 * @author josep
 */

@Getter@Setter@NoArgsConstructor
@Data
@Entity
@Table(name="ships")
public class Barco implements Serializable{
    
    static final long serialVersionUID=137;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    String Nom;
    
    
    @ManyToOne(cascade=CascadeType.PERSIST)
    @JoinColumn(name="IdCapita",
            foreignKey = @ForeignKey(name="")
    )private String Classe;
    
    public Barco(String nom){
        this.Nom=nom;
    }
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(
          name="capita",
          referencedColumnName="IdCapita",
          unique=true,
          foreignKey = @ForeignKey(name="ships_ibfk_2"))
    private Capita elCapita;
    
    
    @Override 
    public String toString() {
        return "{" + Nom + "," + Classe + "," + elCapita + "}";
    }
    
    @ManyToMany(cascade= CascadeType.PERSIST,
            fetch= FetchType.LAZY, 
            mappedBy="losBarcos")
    private Set<Batalla> lesBatalles= new HashSet<>();
    
    
    
}
