/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.ieseljust.psp.apac3.ships;

import Model.Barco;
import Model.Capita;
import org.hibernate.Session;

/**
 *
 * @author josep
 */
public class APAC3Ships {

    public static void main(String[] args) {
        org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.WARNING); 

        Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession();
        laSesion.getTransaction().begin();
        
        Barco b1= new Barco("Titanic");
        Barco b2= new Barco("Barco2");
        
        Capita c1= new Capita("BarbaRoja");
        c1.setElBarco(b1);
        laSesion.save(c1);
        
        
        Capita c2= new Capita("BarbaNegra");
        c2.setElBarco(b2);
        laSesion.save(c2);
        
        laSesion.getTransaction().commit();
        laSesion.close();
    }
}
